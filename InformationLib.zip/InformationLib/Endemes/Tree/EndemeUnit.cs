﻿//--------------------------------------------------------------------------------------------------
// This file is part of the InfoLibCsLesserGpl version of Informationlib.
//
// InformationLib is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// InformationLib is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with InformationLib.  If not, see <http://www.gnu.org/licenses/>.
//--------------------------------------------------------------------------------------------------
using System;                         // for 
using System.Collections.Generic;     // for 
//using System.Linq;                    // for 
using System.Text;                    // for 
using System.Text.RegularExpressions; // for Regex

namespace InformationLib.Endemes.Tree // THIS NAMESPACE IS A PRIMITIVE!  use only System.* or InformationLib.Testing references
{
    // --------------------------------------------------------------------------------------------
    /// <!-- EndemeUnit -->
    /// <summary>
    ///      The EndemeUnit class contains the endeme and its related data (and information)
    /// </summary>
    /// <remarks>
    ///                                                EndemeHIerarchy    -   AbstractComponent   
    ///                                                / (component) \       
    ///                                               /               \      
    ///                               (leaf) EndemeUnit - - - - - - - EndemeNode (composite)
    ///                                        |   ^                       |  (endeme info item)
    ///                                        |   |                       |
    ///                                        |   +-----------------------+
    ///                  EndemeSet             |                            
    ///                    ^   ^               +---------+-------+------+-------+--------+------+
    ///                    |   |               |         |       |      |       |        |      |
    ///                    |   +------------- Endeme   Number   Text   Value   Ordinal  Label  Guid
    ///                    |                   |                        |      (these are the same ordinal, label and guid as above)
    ///                    |  (---- char ----> |                    (anything)
    ///                   /|\                 /|\                             
    ///        EndemeCharacteristic ==== EndemeQuantification                  
    ///                    |
    ///        position -> |              (raw,cooked)
    ///                   /|\
    ///               EndemeValue
    ///               
    /// 
    ///      likely to be deprecated
    /// </remarks>
    public class EndemeUnit : EndemeHierarchy
    {
        // ----------------------------------------------------------------------------------------
        /// <!-- Endeme -->
        /// <summary>
        ///      The main event
        /// </summary>
        /// <value></value>
        /// <returns></returns>
        /// <remarks></remarks>
        public override Endeme Endeme { get; set; }


        // ----------------------------------------------------------------------------------------
        //  Connection to data and information singleton
        // ----------------------------------------------------------------------------------------
      //private InfoInformationBase _infoBase;


        // ----------------------------------------------------------------------------------------
        //  Members for indexing lists etc
        // ----------------------------------------------------------------------------------------
        /// <summary>The label of the item</summary>
        public override string Label   { get; set; }              /// <summary>Not The Guid key of the node or leaf</summary>
        public override int    Ordinal { get { return _ordinal; } } public int _ordinal;


        // ----------------------------------------------------------------------------------------
        //  Members for storing data in an information context
        // ----------------------------------------------------------------------------------------
        // mismatch rate
        // mismatch threshold
        // number of data items expected
        public override object Value   { get; set; }
        public override double Number  { get; set; }
        public override string Text    { get; set; }


        // ----------------------------------------------------------------------------------------
        //  Constructors
        // ----------------------------------------------------------------------------------------
        public EndemeUnit(                                                         ) { Key = Id;              Endeme = null;                                  }
        public EndemeUnit(         Endeme endeme                                   ) { Key = Id; Label = "";  Endeme = endeme;                                }
        public EndemeUnit(         string endeme, EndemeSet set                    ) { Key = Id; Label = "";  Endeme = new Endeme(set, endeme);               }
        public EndemeUnit(Guid id, Endeme endeme                                   ) { Key = id; Label = "";  Endeme = endeme;                                }
        public EndemeUnit(Guid id, Endeme endeme, string lbl                       ) { Key = id; Label = lbl; Endeme = endeme;                                }
        public EndemeUnit(Guid id, Endeme endeme, string lbl, int ord              ) { Key = id; Label = lbl; Endeme = endeme; _ordinal = ord;                }
        public EndemeUnit(Guid id, Endeme endeme, string lbl, int ord, object value) { Key = id; Label = lbl; Endeme = endeme; _ordinal = ord; Value = value; }

        public Guid Id { get { return Guid.NewGuid(); } }

        public EndemeUnit(EndemeUnit item)
        {
            Key      = item.Key;
            Endeme   = item.Endeme.Copy();
            Label    = item.Label;
            Number   = item.Number;
            Text     = item.Text;
            Value    = item.Value; // copying a reference, rather than a value
            Match    = item.Match;
            _ordinal = item.Ordinal;
        }


        public EndemeUnit(EndemeKey info)
        {
            // _infoBase = InfoInformationBase.New();

            
            EndemeSet set    = null; // _infoBase.CharacteristicsFor(info.SetName);
            Endeme    endeme = new Endeme(set, info.Value);
            this.Key         = Guid.NewGuid();
            this.Endeme      = endeme;
            this.Label       = "";

            _ordinal         = info.Index;
        }


        // ----------------------------------------------------------------------------------------
        //  Accessors
        // ----------------------------------------------------------------------------------------
        public override EndemeHierarchy this[Guid   key] { get { if (this.Key     == key) return this; else return new EndemeUnit(); } }
        public override EndemeHierarchy this[string lbl] { get { if (this.Label   == lbl) return this; else return new EndemeUnit(); } }
        public override EndemeHierarchy this[int    ord] { get { if (this.Ordinal == ord) return this; else return new EndemeUnit(); } }
        public override EndemeHierarchy this[Endeme tgt] { get {                          return this;                               } }


		// ----------------------------------------------------------------------------------------
		/// <!-- Add -->
        /// <summary>
        ///      Ignores the component
        /// </summary>
        /// <param name="entity"></param>
        public override EndemeHierarchy Add(EndemeHierarchy item)
        {
            return item;
        }


        // ----------------------------------------------------------------------------------------
        /// <!-- Copy -->
        /// <summary>
        ///      Returns a copy of the EndemeItem where the Value and the Set are references
        /// </summary>
        /// <returns></returns>
        public override EndemeHierarchy Copy()
        {
            EndemeUnit item = new EndemeUnit(this.Key, this.Endeme.Copy(), this.Label);
            item.Match  = this.Match;
            item.Value  = this.Value;                // copying a reference, rather than a value
            item.Number = this.Number;
            item.Text   = this.Text;
            return item;
        }


        // ----------------------------------------------------------------------------------------
        /// <!-- Count -->
        /// <summary>Returns the count of leaves, in this case, 1</summary>
        public override int                     Count { get { return 1; }  }
        public override EndemeHierarchy Info(int i) { return this; }


        // ----------------------------------------------------------------------------------------
        /// <!-- IsEmpty -->
        /// <summary>
        ///      Determines whether the endeme field is empty or blank
        /// </summary>
        /// <value></value>
        /// <returns></returns>
        /// <remarks></remarks>
        public override bool IsEmpty
        {
            get
            {
                if (Endeme == null || Endeme.Count == 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }


        // ----------------------------------------------------------------------------------------
        /// <!-- ToString -->
        /// <summary>
        ///      Default string display
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            string str = "";
            if (Endeme != null)
            {
                if (Endeme.EnSet != null)
                    str = Endeme.EnSet.Label + ":" + Endeme.ToString() + " <" + Match + "> " + Label + " " + Number;
                else
                    str = "NULL:" + Endeme.ToString() + " <" + Match + "> " + Label + " " + Number;
            }
            else str = "NULL" + " <" + Match + "> " + Label + " " + Number;
            if (Value == null) return str;
            else return str + ", " + Value.ToString();
        }
    }
}
