﻿//--------------------------------------------------------------------------------------------------
// This file is part of the InfoLibCsLesserGpl version of Informationlib.
//
// InformationLib is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// InformationLib is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with InformationLib.  If not, see <http://www.gnu.org/licenses/>.
//--------------------------------------------------------------------------------------------------
using System;                         // for 
using System.Collections;             // for 
using System.Collections.Generic;     // for 
using System.Data;                    // for 
using System.Diagnostics;             // for 
using System.Text.RegularExpressions; // for Regex

namespace InformationLib.Endemes.Tree // THIS NAMESPACE IS A PRIMITIVE!  use only System.* or InformationLib.Testing references
{
	// --------------------------------------------------------------------------------------------
	/// <!-- EndemeTree -->
	/// <summary>
	///      The EndemeTree class is the abstract component class in the component pattern,
	///      the leaf is called EndemeElement, the composite is called EndemeNode
	/// </summary>
	/// <remarks>
	///      I have decided to use a modified form of the composite pattern:
	///      Here is the entire structure:
    /// 
    ///                                        +-----------------------------+
    ///                                        |                             |
    ///                                        v                             |
    ///                             ordinal -> |                             |
    ///                            +---------> |                             |
    ///                            |  label -> |                             |
    ///                            |  idx ---> | EndemeTreeAbstractComponent |
    ///                            |  Guid --> |      / (component)  \       |
    ///                            |          /|\    /                \      |
    ///                            | (leaf) EndemeItem - - - - - - - - EndemeCollection (composite)
    ///                            |           |   ^                         |  (endeme info item)
    ///                            |           |   |                         |
    ///                            |           |   +-------------------------+
    ///                  EndemeSet |           |                            
    ///                    ^   ^   |           +---------+-------+------+-------+--------+------+
    ///                    |   |   |           |         |       |      |       |        |      |
    ///                    |   +---+--------- Endeme   Number   Text   Value   Ordinal  Label  Guid
    ///                    |                   |                        |      (these are the same ordinal, label and guid as above)
    ///                    |  (---- char ----> |                    (anything)
    ///                   /|\                 /|\                             
    ///        EndemeCharacteristic ==== EndemeQuantification                  
    ///                    |
    ///        position -> |              (raw,cooked)
    ///                   /|\
    ///               EndemeValue
	/// 
	///      TODO:
	/// 
	///             knowledge database access
	///      [PART]  - direct                          
	///              - indirect
	///              - excel
	///      [PART]  - auto-construction
	///              - auto-populating
	///              - osmosis
	/// 
	///             paths
	///              - lower level endeme sets
	///              - higher level endeme sets
	///              - hierarchical paths
	///              - relational paths
	/// 
	///             level converters
	///              - EndemeSet to EndemeList
	///              - EndemeCollection to EndemeSet
	///              - valued characteristic to EndemeSet
	/// 
	///             fuzzy converters
	///              - EndemeNodeConnector to Fuzzylist
	///              - FuzzyList to EndemeNodeConnector
	///              - EndemeValue to FuzzyTerm
	///              - FuzzyTerm to EndemeValue
	///              - EndemeCharacteristic to FuzzyMeasure
	///              - FuzzyMeasure to EndemeCharacteristic
	///              - EndemeCollection to FuzzyList
	///              - EndemeSet to FuzzyList
	/// 
	///             non-info
	///              - RichSqlCommand factory generate stored procedure test strings
	///              - install old test code
	/// 
    /// 
    ///      likely to be deprecated
	/// </remarks>
	public abstract class EndemeHierarchy
	{
		// ----------------------------------------------------------------------------------------
		//  Members
		// ----------------------------------------------------------------------------------------
		public abstract Endeme Endeme  { get; set; } /// <summary>The label of the node or leaf</summary>
		public abstract string Label   { get; set; } /// <summary>The Guid key of the node or leaf</summary>
		public          Guid   Key     { get; set; } /// <summary>The specified ordinal of the node or leaf</summary>
        public abstract int    Ordinal { get;      }

		public abstract object Value   { get; set; }
		public abstract double Number  { get; set; }
		public abstract string Text    { get; set; }
        public          double Match   { get; set; }


		// ----------------------------------------------------------------------------------------
        //  Accessors
		// ----------------------------------------------------------------------------------------
        public abstract EndemeHierarchy this[Guid   key] { get; }
        public abstract EndemeHierarchy this[string lbl] { get; }
        public abstract EndemeHierarchy this[int    ord] { get; }
        public abstract EndemeHierarchy this[Endeme tgt] { get; }


		// ----------------------------------------------------------------------------------------
		/// <!-- Add -->
        /// <summary>
        ///      Adds a component to the list or ignores it if the component added to is an item
        /// </summary>
        /// <param name="entity"></param>
        public abstract EndemeHierarchy Add(EndemeHierarchy entity);


		// ----------------------------------------------------------------------------------------
		/// <!-- Copy -->
		/// <summary>
		///      Returns a copy of the EndemeAbstractComponent
		/// </summary>
		/// <returns></returns>
		public abstract EndemeHierarchy Copy();


		// ----------------------------------------------------------------------------------------
		/// <!-- Count -->
		/// <summary>
		///      Returns the count of leaves
		/// </summary>
		/// <value></value>
		/// <returns></returns>
		/// <remarks></remarks>
		public abstract int Count { get; }


		// ----------------------------------------------------------------------------------------
		/// <!-- Info -->
        /// <summary>
        ///      Returns the first item on the EndemeCollection or the item itself if it an EndemeItem
        /// </summary>
        /// <param name="i"></param>
        /// <returns></returns>
        public abstract EndemeHierarchy Info(int i);


		// ----------------------------------------------------------------------------------------
		/// <!-- IsEmpty -->
		/// <summary>
		///      Determines whether the component is empty
		/// </summary>
		/// <value></value>
		/// <returns></returns>
		/// <remarks></remarks>
		public abstract bool IsEmpty { get; }


        public override string ToString()
        {
            return base.ToString();
        }
    }
}