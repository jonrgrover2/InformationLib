//--------------------------------------------------------------------------------------------------
// This file is part of the InfoLibCsLesserGpl version of Informationlib.
//
// InformationLib is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// InformationLib is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with InformationLib.  If not, see <http://www.gnu.org/licenses/>.
//--------------------------------------------------------------------------------------------------
using System;                         // for 
using System.Collections.Generic;     // for Dictionary, List
using System.Linq;                    // for 
using System.Text.RegularExpressions; // for Regex

namespace InformationLib.Endemes.Tree // THIS NAMESPACE IS A PRIMITIVE!  use only System.* or InformationLib.Testing references
{
    // --------------------------------------------------------------------------------------------
    /// <!-- EndemeNode -->
    /// <summary>
    ///      The EndemeNode class contains a Guid keyed, labeled, ordered, label indexed list of endemes
    /// </summary>
    /// <remarks>
    ///      An endeme tree is managed a bit like a two-column special purpose database table with the label
    ///      put into the EndemeItem class
    /// 
    ///                                        +-----------------------------+
    ///                                        |                             |
    ///                                        v                             |
    ///                             ordinal -> |                             |
    ///                            +---------> |                             |
    ///                            |  label -> |                             |
    ///                            |  idx ---> |   EndemeAbstractComponent   |
    ///                            |  Guid --> |      / (component)  \       |
    ///                            |          /|\    /                \      |
    ///                            | (leaf) EndemeElement - - - - - - - OldEndemeNode (composite)
    ///                            |           |   ^                         |  (endeme info item)
    ///                            |           |   |                         |
    ///                            |           |   +-------------------------+
    ///                  EndemeSet |           |                            
    ///                    ^   ^   |           +---------+-------+------+-------+--------+------+
    ///                    |   |   |           |         |       |      |       |        |      |
    ///                    |   +---+--------- Endeme   Number   Text   Value   Ordinal  Label  Guid
    ///                    |                   |                        |      (these are the same
    ///                    |  (---- char ----> |                    (anything)  ordinal, label and
    ///                   /|\                 /|\                               guid as above)
    ///        EndemeCharacteristic ==== EndemeQuantification                  
    ///                    |
    ///        position -> |              (raw,cooked)
    ///                   /|\
    ///               EndemeValue
    /// 
    /// 
    /// 
    ///      Parallel Levels of Complexity Among Various Information Structures:
    /// 
    /// 
    ///      (EndemeCollection)    = = = (FuzzyList)
    ///         |                           |
    ///         |                           |
    ///      EndemeSet, (Endeme)            |
    ///      (EndemeItem)                   |
    ///         |                        FuzzyMeasure, 
    ///         |                  = ? = (FuzzyItem)
    ///      EndemeCharacteristic           |
    ///         |                           |
    ///         |                        FuzzyTerm
    ///         |                  = ? =    
    ///      EndemeValue                    
    /// 
    /// 
    ///      likely to be deprecated
    /// </remarks>
    public class EndemeNode : EndemeHierarchy
    {
        // ----------------------------------------------------------------------------------------
        //  Members
        // ----------------------------------------------------------------------------------------
        private List<EndemeHierarchy> _list;     // composite components?
        private Dictionary<string, List<int>> _lblIndex; // 'label' above          (associative index)
		private Dictionary<string, List<int>> _setIndex; // part of 'Endeme' above (info index)
        private Dictionary<int   , List<int>> _ordIndex; // 'ordinal' above        (offical index)
        private Dictionary<Guid  , List<int>> _keyIndex; // 'Guid' above           (universal index)
        private EndemeUnit                    _item;     // 'EndemeItem' above


        // ----------------------------------------------------------------------------------------
        //  Connection to data and information singleton
        // ----------------------------------------------------------------------------------------
      //private InfoInformationBase _infoBase;


        // ----------------------------------------------------------------------------------------
        //  Accessors
        // ----------------------------------------------------------------------------------------
        public override EndemeHierarchy this[Guid   key] { get { if (_keyIndex.ContainsKey(key)) { return OutputList(_keyIndex[key]); } else return new EndemeUnit(); } }
        public override EndemeHierarchy this[string lbl] { get { if (_lblIndex.ContainsKey(lbl)) { return OutputList(_lblIndex[lbl]); } else return new EndemeUnit(); } }
        public override EndemeHierarchy this[int    ord] { get { if (_ordIndex.ContainsKey(ord)) { return OutputList(_ordIndex[ord]); } else return new EndemeNode(); } }
        public override EndemeHierarchy this[Endeme tgt] { get { return FindClosest_sequentialSearch(1, tgt); } }
        public          EndemeHierarchy GetItem(int idx)       { return _list[idx];                           }


        public EndemeHierarchy OutputList(List<int> index)
        {
            EndemeNode list = new EndemeNode();
            for (int i = 0; i < index.Count; ++i)
            {
                int idx = index[i];
                list.Add(_list[idx]);
            }
            return list;
        }


        // ----------------------------------------------------------------------------------------
        //  Constructors
        // ----------------------------------------------------------------------------------------
        public EndemeNode()
        {
            Init();
            _item = new EndemeUnit(Guid.NewGuid(), null);
        }

        private void Init()
        {
            _list = new List<EndemeHierarchy>();

            _lblIndex = new Dictionary<string,List<int>>();
            _setIndex = new Dictionary<string,List<int>>();
            _ordIndex = new Dictionary<int   ,List<int>>();
            _keyIndex = new Dictionary<Guid  ,List<int>>();

            //_infoBase = InfoInformationBase.New();
        }

        public EndemeNode(EndemeKey info)
        {
            Init();

            string       setName = info.SetName;
            EndemeSet    set     = new EndemeSet(setName);
                         //set     = _infoBase.CharacteristicsFor(info.SetName);
            Endeme       endeme  = new Endeme(set, info.Value);

            _item = new EndemeUnit(info);
        }

         
        // ----------------------------------------------------------------------------------------
        //  Short methods and properties
        // ----------------------------------------------------------------------------------------
        public override EndemeHierarchy Info(int i) { return _list[i];                      }
        public override int    Count   { get { return _list.Count;                                  } }
        public override bool   IsEmpty { get { if (Count == 0) return true; else return false;      } }
        public override Endeme Endeme  { get { return _item.Endeme;  } set { _item.Endeme  = value; } }
        public override string Label   { get { return _item.Label;   } set { _item.Label   = value; } }
        public override int    Ordinal { get { return _item.Ordinal; }                                }
        public override object Value   { get { return _item.Value;   } set { _item.Value   = value; } }
        public override double Number  { get { return _item.Number;  } set { _item.Number  = value; } }
        public override string Text    { get { return _item.Text;    } set { _item.Text    = value; } }


        // ----------------------------------------------------------------------------------------
        /// <!-- Add -->
        /// <summary>
        ///      Add labeled endeme item (leaf) or endeme list (node) to the endeme list
        /// </summary>
        /// <param name="key">enter an empty to make it random</param>
        /// <param name="label"></param>
        /// <param name="endeme">endeme to add</param>
        /// <param name="value">value to store</param>
        public override EndemeHierarchy Add(EndemeHierarchy item)
        {
            int idx = _list.Count;
            _list.Add(item);

            IndexLbl(item.Label  , idx);
            IndexKey(item.Key    , idx);
            IndexOrd(item.Ordinal, idx);
            if (item.Endeme != null)
                IndexSet(item.Endeme.EnSet.Label, idx);
            else
                Pause();

            return item;
        }

        private void Pause()
        {
        } // does not crash
        private void IndexSet(string set, int idx) { set=set.ToLower(); if (set != null) { if (!_setIndex.ContainsKey(set)) try { _setIndex.Add(set, new List<int>()); } catch { } _setIndex[set].Add(idx); } }
        private void IndexOrd(int    ord, int idx) {                    if                    (!_ordIndex.ContainsKey(ord)) try { _ordIndex.Add(ord, new List<int>()); } catch { } _ordIndex[ord].Add(idx); }
        private void IndexKey(Guid   key, int idx) {                    if (key != null) { if (!_keyIndex.ContainsKey(key)) try { _keyIndex.Add(key, new List<int>()); } catch { } _keyIndex[key].Add(idx); } }
        private void IndexLbl(string lbl, int idx) {                    if (lbl != null) { if (!_lblIndex.ContainsKey(lbl)) try { _lblIndex.Add(lbl, new List<int>()); } catch { } _lblIndex[lbl].Add(idx); } }


        // ----------------------------------------------------------------------------------------
        //  Adding items
        // ----------------------------------------------------------------------------------------
        private EndemeUnit AddItem(Guid key, Endeme endeme, string label, int ord, object value)
        {
            EndemeUnit item = new EndemeUnit(key, endeme, label, ord, value);
            Add(item);
            return item;
        } // does not crash
        public EndemeHierarchy AddItem(Endeme endeme                                             ) { return AddItem(Guid.NewGuid(), endeme, "" , 0  , null ); } // does not crash
        public EndemeHierarchy AddItem(Endeme endeme          , string lbl         , object value) { return AddItem(Guid.NewGuid(), endeme, "" , 0  , value); }
        public EndemeHierarchy AddItem(Endeme endeme          , string lbl                       ) { return AddItem(Guid.NewGuid(), endeme, lbl, 0  , null ); } // does not crash
        public EndemeHierarchy AddItem(Endeme endeme          , string lbl, int ord              ) { return AddItem(Guid.NewGuid(), endeme, lbl, ord, null ); }
        public EndemeHierarchy AddItem(Endeme endeme, Guid key                                   ) { return AddItem(key           , endeme, "" , 0  , null ); }
        public EndemeHierarchy AddItem(Endeme endeme, Guid key, string lbl                       ) { return AddItem(key           , endeme, lbl, 0  , null ); }
        public EndemeHierarchy AddItem(Endeme endeme, Guid key, string lbl, int ord, object value) { return AddItem(key           , endeme, lbl, 0  , value); }
        public EndemeHierarchy AddItem(Endeme endeme, Guid key, string lbl, int ord              ) { return AddItem(key           , endeme, lbl, ord, null ); }


        // ----------------------------------------------------------------------------------------
        /// <!-- AddList -->
        /// <summary>
        ///      Initiates a list as an item in the list
        /// </summary>
        /// <param name="endeme"></param>
        /// <param name="lbl"></param>
        /// <returns></returns>
        public EndemeNode AddList(Endeme endeme, string lbl)
        {
            EndemeNode list = new EndemeNode();
            list.Label  = lbl;
            list.Endeme = endeme;
            Add(list);
            return list;
        }

        // ----------------------------------------------------------------------------------------
        /// <!-- AddList -->
        /// <summary>
        ///      Adds a list as an item in the list
        /// </summary>
        /// <param name="list">the list to be added</param>
        /// <param name="endeme"></param>
        /// <param name="lbl"></param>
        /// <returns></returns>
        public EndemeNode AddList(EndemeNode list, Endeme endeme, string lbl)
        {
            list.Label  = lbl;
            list.Endeme = endeme;
            Add(list);
            return list;
        }

        // ----------------------------------------------------------------------------------------
        /// <!-- Copy -->
        /// <summary>
        ///      Returns a copy of the endeme list
        /// </summary>
        /// <returns></returns>
        public override EndemeHierarchy Copy()
        {
            EndemeNode list = new EndemeNode();
            for (int i = 0; i < _list.Count; ++i)
                list._list.Add(_list[i].Copy());
            return list;
        }

        // ----------------------------------------------------------------------------------------
        /// <!-- Enter -->
        /// <summary>
        ///      Enters a value into the information structure where the path says to enter it
        /// </summary>
        /// <param name="infoPath"></param>
        /// <param name="value"></param>
        public void Enter(string infoPath, string value)
        {
            Enter(ParsePath(infoPath), value);
        }

        // ----------------------------------------------------------------------------------------
        /// <!-- Enter -->
        /// <summary>
        ///      Enters a value into the information structure where the path says to enter it
        /// </summary>
        /// <param name="segment"></param>
        /// <param name="value"></param>
        private void Enter(List<EndemeKey> segment, string value)
        {
            if (segment.Count == 0)  return;
            if (segment.Count == 1)
            {
                // ----------------------------------------------------------------------
                //  If it is a leaf: create an endeme item and add that to the endeme list
                // ----------------------------------------------------------------------
                EndemeUnit  item = (EndemeUnit)this.Add(new EndemeUnit(segment[0]));
                item.Value = value;
            }
            else
            {
                // look for a place to add it
                EndemeKey info = segment[0];

                // if it is a branch:
                //  1. create an endeme list (with its own endeme item)
                EndemeNode list = new EndemeNode(segment[0]);
                //EndemeItem item = new EndemeItem(segment[0], schema);
                //list.Add(item);
                //  2. add the lew list to the list, a list is a component should it have an endeme
                this.Add(list);
                //  3. remove the first segment from the infopath
                segment.RemoveAt(0);
                //  4. recursively call Enter with a shortened infoPath
                list.Enter(segment, value);
            }
        }

        // ----------------------------------------------------------------------------------------
        /// <!-- FindClosest_sequentialSearch -->
        /// <summary>
        ///      Matches every item in the list to find the closest item to the input endeme
        /// </summary>
        /// <param name="n">ignored</param>
        /// <param name="tgtEndeme"></param>
        /// <returns></returns>
        internal EndemeHierarchy FindClosest_sequentialSearch(int n, Endeme tgtEndeme)
        {
            EndemeSet targetSet = tgtEndeme.EnSet;


            // --------------------------------------------------------------------------
            //  Calculate the match with every item in the set
            // --------------------------------------------------------------------------
            EndemeHierarchy obj = OutputList(_setIndex[targetSet.Label]);
            if (obj.GetType() == typeof(EndemeUnit))
                return obj;
            EndemeNode all = (EndemeNode)obj;
            for (int i = 0; i < all.Count; ++i)
            {
                EndemeHierarchy item = all.Info(i);
                item.Match = tgtEndeme.Match(item.Endeme, WeightFormula.Refined);
            }


            // --------------------------------------------------------------------------
            //  Order the matches
            // --------------------------------------------------------------------------
            Dictionary<int,double> match = new Dictionary<int,double>(all.Count);
            List<EndemeHierarchy> items = new List<EndemeHierarchy>(all.Count);
            for (int i = 0; i < all.Count; ++i)
            {
                items.Add(all.Info(i));
                match.Add(i,all.Info(i).Match);
            }
            List<int> ordered = match.OrderByDescending(m => m.Value).Select(m => m.Key).ToList();


            // --------------------------------------------------------------------------
            //  Return a list
            // --------------------------------------------------------------------------
            EndemeNode output = new EndemeNode();
            for (int i = 0; i < ordered.Count; ++i)
            {
                output.Add(items[i]);
            }
            return output;
        }

        // ----------------------------------------------------------------------------------------
        /// <!-- ParsePath -->
        /// <summary>
        ///      Parses a path into an InfoSegment list
        /// </summary>
        /// <param name="infoPath"></param>
        /// <returns></returns>
        public static List<EndemeKey> ParsePath(string infoPath)
        {
            string[] list = infoPath.Split("/".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
            List<EndemeKey> segment = new List<EndemeKey>(list.Length);
            for (int i = 0; i < list.Length; ++i)
                segment.Add(new EndemeKey(list[i]));
            return segment;
        }

        // ----------------------------------------------------------------------------------------
        /// <!-- QueryOne -->
        /// <summary>
        ///      Returns the best match for the information path
        /// </summary>
        /// <param name="infoPath"></param>
        /// <returns></returns>
        public EndemeHierarchy QueryOne(string infoPath)
        {
            List<EndemeKey> path = ParsePath(infoPath);
            EndemeHierarchy item = new EndemeUnit();


            for (int i = 0; i < path.Count; ++i)
            {
                EndemeNode list = this;
                if (i > 0)
                    list = (EndemeNode)item;
                EndemeKey hi = path[i];
                item = list.QueryOne(hi);
            }


            return item;
        }

        // ----------------------------------------------------------------------------------------
        /// <!-- QueryOne -->
        /// <summary>
        ///      Returns the best match for the information path segment
        /// </summary>
        /// <param name="segment"></param>
        /// <returns></returns>
        private EndemeHierarchy QueryOne(EndemeKey segment)
        {
            EndemeHierarchy item = null;
            string setName = segment.SetName.ToLower();
            Endeme e2 = new Endeme(segment.Value);


            if (_setIndex.ContainsKey(setName))
            {
                // go through the list of items for that endeme set
                List<int> list = _setIndex[setName];
                // and find the best one that is good enough
                double bestmatch = 0.0;

                for (int i = 0; i < list.Count; ++i)
                {
                    int idx = list[i];
                    EndemeHierarchy one = _list[idx];
                    Endeme e1 = one.Endeme;
                    double match = e1.Match(e2, WeightFormula.Refined);
                    if (match >= bestmatch)
                    {
                        bestmatch = match;
                        item = one;
                    }
                }
            }

            return item;
        }

        // ----------------------------------------------------------------------------------------
        /// <!-- ToString -->
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            if (_item.Endeme.EnSet == null)
                return "NULL:" + _item.Endeme.ToString() + " (" + _list.Count.ToString() + ")";
            else
                return _item.Endeme.EnSet.Label + ":" + _item.Endeme.ToString() + " (" + _list.Count.ToString() + ")";
        }
    }
}
