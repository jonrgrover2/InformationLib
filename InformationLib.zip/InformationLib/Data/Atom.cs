﻿using System.Collections.Generic;

namespace InformationLib.Data
{
    // --------------------------------------------------------------------------------------------
    //  Atoms and elements
    /* ----------------------------------------------------------------------------------------- */  /// <summary>Atom: a List of string-object Dictionaries</summary>
    public class Atom   : List<Dictionary<string, object>> { }                                       /// <summary>Carbon: a List of string-string Dictionaries</summary>
    public class Carbon : List<Dictionary<string, string>> { }


    // --------------------------------------------------------------------------------------------
    //  Particles and sub-particles
    /* ----------------------------------------------------------------------------------------- */  /// <summary>Particle: a string-object Dictionary[string,object]</summary>
    public class Particle : Dictionary<string, object> { }                                           /// <summary>Neutron: a string-string Dictionary[string,string]</summary>
    public class Neutron  : Dictionary<string, string> { }
}
