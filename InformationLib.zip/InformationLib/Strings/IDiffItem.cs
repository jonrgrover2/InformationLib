﻿//--------------------------------------------------------------------------------------------------
// This file is part of the InfoLibCsLesserGpl version of Informationlib.
//
// InformationLib is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// InformationLib is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with InformationLib.  If not, see <http://www.gnu.org/licenses/>.
//--------------------------------------------------------------------------------------------------
using System;                         // for 
using System.Collections.Generic;     // for 
//using System.Linq;                    // for 
using System.Text;                    // for 
using System.Text.RegularExpressions; // for Regex

namespace InformationLib.Strings // THIS NAMESPACE IS A PRIMITIVE!  use only System.* or InformationLib.Testing references
{
    // --------------------------------------------------------------------------------------------
    /// <!-- IDiffItem -->
    /// <summary>
    ///      The IDiffItem interface standardizes the format of DiffItems making recursion possible.
    /// </summary>
    /// <remarks>alpha code</remarks>
    public interface IDiffItem
    {
        /// <summary>-1, 0, or 1</summary>
        int    Change  { get; } /// <summary>file, folder, method, or item name</summary>
        string Str     { get; }
        string Parent1 { get; set; }
        string Parent2 { get; set; }
        string Parent   (int x);
        int    Direction(int x);
    }
}
